@echo off
setlocal
set "TASK_NODE=%ProgramFiles%\nodejs\node.exe"
if not exist "%TASK_NODE%" (
 echo Node 24.18 or later 24.x x64 is required. Ask Codex to assist with the official installer.
 exit /b 1
)
"%TASK_NODE%" "%~dp0source\collaboration\install-package.mjs"
exit /b %errorlevel%
